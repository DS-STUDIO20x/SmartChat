require("dotenv").config();
const express = require("express");
const http = require("http");
const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const cors = require("cors");
const { Server } = require("socket.io");

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: "*" } });

app.use(cors());
app.use(express.json());
app.use(express.static("public"));

// MongoDB models
const UserSchema = new mongoose.Schema({
  name: String,
  phone: String,
  passwordHash: String
});

const MessageSchema = new mongoose.Schema({
  conversationId: String,
  from: String,
  text: String,
  createdAt: { type: Date, default: Date.now }
});

const ConversationSchema = new mongoose.Schema({
  type: { type: String, enum: ["dm", "group"], default: "dm" },
  members: [String],
  name: String,
  admins: [String]
});

const User = mongoose.model("User", UserSchema);
const Message = mongoose.model("Message", MessageSchema);
const Conversation = mongoose.model("Conversation", ConversationSchema);

// Mongo connect
mongoose.connect(process.env.MONGO_URI).then(() => {
  console.log("MongoDB connected");
});

// Auth middleware
function authMiddleware(req, res, next) {
  const token = req.headers.authorization?.split(" ")[1];
  if (!token) return res.status(401).json({ error: "Unauthorized" });
  try {
    req.user = jwt.verify(token, process.env.JWT_SECRET);
    next();
  } catch (err) {
    res.status(401).json({ error: "Invalid token" });
  }
}

// Auth routes
app.post("/signup", async (req, res) => {
  const { name, phone, password } = req.body;
  const passwordHash = await bcrypt.hash(password, 10);
  const user = await User.create({ name, phone, passwordHash });
  res.json(user);
});

app.post("/login", async (req, res) => {
  const { phone, password } = req.body;
  const user = await User.findOne({ phone });
  if (!user) return res.status(400).json({ error: "User not found" });
  const ok = await bcrypt.compare(password, user.passwordHash);
  if (!ok) return res.status(400).json({ error: "Wrong password" });
  const token = jwt.sign({ id: user._id, phone }, process.env.JWT_SECRET);
  res.json({ token, user });
});

// Socket.io events
io.use((socket, next) => {
  try {
    const token = socket.handshake.auth.token;
    const user = jwt.verify(token, process.env.JWT_SECRET);
    socket.user = user;
    next();
  } catch (err) {
    next(new Error("Unauthorized"));
  }
});

io.on("connection", (socket) => {
  console.log("User connected:", socket.user.phone);

  socket.on("join_conversation", (conversationId) => {
    socket.join(conversationId);
  });

  socket.on("send_message", async ({ conversationId, text }) => {
    const msg = await Message.create({
      conversationId,
      from: socket.user.id,
      text
    });
    io.to(conversationId).emit("message", msg);
  });

  socket.on("disconnect", () => {
    console.log("User disconnected");
  });
});

// Start server
const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log(Server running on port ${PORT}));